from enum import IntEnum, unique

class ProtoError(Exception):
    def __init__(self, msg):
        self.msg = msg
    def __str__(self):
        return repr(self.msg)

@unique
class ProtoFieldType(IntEnum):
    VARINT = 0
    INT64 = 1
    STRING = 2
    GROUPSTART = 3
    GROUPEND = 4
    INT32 = 5
    ERROR1 = 6
    ERROR2 = 7

class ProtoField:
    def __init__(self, idx, type, val):
        self.idx = idx
        self.type = type
        self.val = val

    def isAsciiStr(self):
        if not isinstance(self.val, bytes):
            return False
        return all(0x20 <= b <= 0x7e for b in self.val)

class ProtoReader:
    def __init__(self, data):
        self.data = data
        self.pos = 0

    def seek(self, pos):
        self.pos = pos

    def isRemain(self, length):
        return self.pos + length <= len(self.data)

    def read0(self):
        assert self.isRemain(1)
        ret = self.data[self.pos]
        self.pos += 1
        return ret & 0xFF

    def read(self, length):
        assert self.isRemain(length)
        ret = self.data[self.pos:self.pos+length]
        self.pos += length
        return ret

    def readInt32(self):
        return int.from_bytes(self.read(4), byteorder='little', signed=False)

    def readInt64(self):
        return int.from_bytes(self.read(8), byteorder='little', signed=False)

    def readVarint(self):
        vint = 0
        n = 0
        while True:
            byte = self.read0()
            vint |= ((byte & 0x7F) << (7 * n))
            if byte < 0x80:
                break
            n += 1
        return vint

    def readString(self):
        length = self.readVarint()
        return self.read(length)

class ProtoWriter:
    def __init__(self):
        self.data = bytearray()

    def write0(self, byte):
        self.data.append(byte & 0xFF)

    def write(self, bytes_val):
        self.data.extend(bytes_val)

    def writeInt32(self, int32):
        self.write(int32.to_bytes(4, byteorder='little', signed=False))

    def writeInt64(self, int64):
        self.write(int64.to_bytes(8, byteorder='little', signed=False))

    def writeVarint(self, vint):
        vint = vint & 0xFFFFFFFF
        while vint > 0x80:
            self.write0((vint & 0x7F) | 0x80)
            vint >>= 7
        self.write0(vint & 0x7F)

    def writeString(self, bytes_val):
        self.writeVarint(len(bytes_val))
        self.write(bytes_val)

    def toBytes(self):
        return bytes(self.data)

class ProtoBuf:
    def __init__(self, data=None):
        self.fields = []
        if data is not None:
            if not isinstance(data, (bytes, dict)):
                raise ProtoError(f'unsupport type({type(data)}) to protobuf')
            if isinstance(data, bytes) and len(data) > 0:
                self._parseBuf(data)
            elif isinstance(data, dict) and len(data) > 0:
                self._parseDict(data)

    def __getitem__(self, idx):
        pf = self.get(int(idx))
        if pf is None:
            return None
        if pf.type != ProtoFieldType.STRING:
            return pf.val
        if pf.val is None:
            return None
        if pf.isAsciiStr():
            return pf.val.decode('utf-8')
        return ProtoBuf(pf.val)

    def _parseBuf(self, bytes_val):
        reader = ProtoReader(bytes_val)
        while reader.isRemain(1):
            key = reader.readVarint()
            field_type = ProtoFieldType(key & 0x7)
            field_idx = key >> 3
            if field_idx == 0:
                break
            if field_type == ProtoFieldType.INT32:
                self.put(ProtoField(field_idx, field_type, reader.readInt32()))
            elif field_type == ProtoFieldType.INT64:
                self.put(ProtoField(field_idx, field_type, reader.readInt64()))
            elif field_type == ProtoFieldType.VARINT:
                self.put(ProtoField(field_idx, field_type, reader.readVarint()))
            elif field_type == ProtoFieldType.STRING:
                self.put(ProtoField(field_idx, field_type, reader.readString()))
            else:
                raise ProtoError(f'parse protobuf error, unexpected field type: {field_type.name}')

    def toBuf(self):
        writer = ProtoWriter()
        for field in self.fields:
            key = (field.idx << 3) | (field.type & 7)
            writer.writeVarint(key)
            if field.type == ProtoFieldType.INT32:
                writer.writeInt32(field.val)
            elif field.type == ProtoFieldType.INT64:
                writer.writeInt64(field.val)
            elif field.type == ProtoFieldType.VARINT:
                writer.writeVarint(field.val)
            elif field.type == ProtoFieldType.STRING:
                writer.writeString(field.val)
            else:
                raise ProtoError(f'encode to protobuf error, unexpected field type: {field.type.name}')
        return writer.toBytes()

    def get(self, idx):
        for field in self.fields:
            if field.idx == idx:
                return field
        return None

    def put(self, field: ProtoField):
        self.fields.append(field)

    def putInt32(self, idx, int32):
        self.put(ProtoField(idx, ProtoFieldType.INT32, int32))

    def putInt64(self, idx, int64):
        self.put(ProtoField(idx, ProtoFieldType.INT64, int64))

    def putVarint(self, idx, vint):
        self.put(ProtoField(idx, ProtoFieldType.VARINT, vint))

    def putBytes(self, idx, data):
        self.put(ProtoField(idx, ProtoFieldType.STRING, data))

    def putUtf8(self, idx, data):
        self.put(ProtoField(idx, ProtoFieldType.STRING, data.encode('utf-8')))

    def putProtoBuf(self, idx, data):
        self.put(ProtoField(idx, ProtoFieldType.STRING, data.toBuf()))

    def _parseDict(self, data):
        for k, v in data.items():
            if isinstance(v, int):
                self.putVarint(k, v)
            elif isinstance(v, str):
                self.putUtf8(k, v)
            elif isinstance(v, bytes):
                self.putBytes(k, v)
            elif isinstance(v, dict):
                self.putProtoBuf(k, ProtoBuf(v))
            else:
                raise ProtoError(f'unsupport type({type(v)}) to protobuf')