class SM3:
    def __init__(self) -> None:
        self.IV = [1937774191, 1226093241, 388252375, 3666478592, 2842636476, 372324522, 3817729613, 2969243214]
        self.TJ = [2043430169] * 16 + [2055708042] * 48

    def __rotate_left(self, a: int, k: int) -> int:
        k = k % 32
        return ((a << k) & 0xFFFFFFFF) | ((a & 0xFFFFFFFF) >> (32 - k))

    def __FFJ(self, X: int, Y: int, Z: int, j: int) -> int:
        if 0 <= j < 16:
            return X ^ Y ^ Z
        else:
            return (X & Y) | (X & Z) | (Y & Z)

    def __GGJ(self, X: int, Y: int, Z: int, j: int) -> int:
        if 0 <= j < 16:
            return X ^ Y ^ Z
        else:
            return (X & Y) | ((~X) & Z)

    def __P_0(self, X: int) -> int:
        return X ^ (self.__rotate_left(X, 9)) ^ (self.__rotate_left(X, 17))

    def __P_1(self, X: int) -> int:
        return X ^ (self.__rotate_left(X, 15)) ^ (self.__rotate_left(X, 23))

    def __CF(self, V_i: list, B_i: bytearray) -> list:
        W = []
        for i in range(16):
            weight = 0x1000000
            data = 0
            for k in range(i * 4, (i + 1) * 4):
                data = data + B_i[k] * weight
                weight = int(weight / 0x100)
            W.append(data)
        for j in range(16, 68):
            W.append(0)
            W[j] = (self.__P_1(W[j - 16] ^ W[j - 9] ^ (self.__rotate_left(W[j - 3], 15)))
                    ^ (self.__rotate_left(W[j - 13], 7)) ^ W[j - 6])
        W_1 = [W[j] ^ W[j + 4] for j in range(64)]
        A, B, C, D, E, F, G, H = V_i
        for j in range(64):
            SS1 = self.__rotate_left(((self.__rotate_left(A, 12)) + E + (self.__rotate_left(self.TJ[j], j))) & 0xFFFFFFFF, 7)
            SS2 = SS1 ^ (self.__rotate_left(A, 12))
            TT1 = (self.__FFJ(A, B, C, j) + D + SS2 + W_1[j]) & 0xFFFFFFFF
            TT2 = (self.__GGJ(E, F, G, j) + H + SS1 + W[j]) & 0xFFFFFFFF
            D = C
            C = self.__rotate_left(B, 9)
            B = A
            A = TT1
            H = G
            G = self.__rotate_left(F, 19)
            F = E
            E = self.__P_0(TT2)
        return [
            A & 0xFFFFFFFF ^ V_i[0],
            B & 0xFFFFFFFF ^ V_i[1],
            C & 0xFFFFFFFF ^ V_i[2],
            D & 0xFFFFFFFF ^ V_i[3],
            E & 0xFFFFFFFF ^ V_i[4],
            F & 0xFFFFFFFF ^ V_i[5],
            G & 0xFFFFFFFF ^ V_i[6],
            H & 0xFFFFFFFF ^ V_i[7],
        ]

    def sm3_hash(self, msg: bytes) -> bytes:
        msg = bytearray(msg)
        len1 = len(msg)
        reserve1 = len1 % 64
        msg.append(0x80)
        reserve1 += 1
        range_end = 56
        if reserve1 > range_end:
            range_end += 64
        for i in range(reserve1, range_end):
            msg.append(0x00)
        bit_length = (len1) * 8
        bit_length_str = [bit_length % 0x100]
        for i in range(7):
            bit_length = int(bit_length / 0x100)
            bit_length_str.append(bit_length % 0x100)
        for i in range(8):
            msg.append(bit_length_str[7 - i])
        group_count = round(len(msg) / 64)
        B = [msg[i * 64: (i + 1) * 64] for i in range(group_count)]
        V = [self.IV]
        for i in range(group_count):
            V.append(self.__CF(V[i], B[i]))
        y = V[-1]
        res = b"".join(int(i).to_bytes(4, "big") for i in y)
        return res