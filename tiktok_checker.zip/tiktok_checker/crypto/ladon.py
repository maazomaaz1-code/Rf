import hashlib
import ctypes
import base64
import os
from lib.pkcs7_padding import pkcs7_padding_pad_buffer, padding_size

def md5bytes(data: bytes) -> str:
    m = hashlib.md5()
    m.update(data)
    return m.hexdigest()

def validate(num):
    return num & 0xFFFFFFFFFFFFFFFF

def __ROR__(value: ctypes.c_ulonglong, count: int) -> ctypes.c_ulonglong:
    nbits = ctypes.sizeof(value) * 8
    count %= nbits
    low = ctypes.c_ulonglong(value.value << (nbits - count)).value
    value = ctypes.c_ulonglong(value.value >> count).value
    return value | low

def set_type_data(ptr, index, data, data_type):
    if data_type == "uint64_t":
        ptr[index * 8: (index + 1) * 8] = data.to_bytes(8, "little")

def encrypt_ladon_input(hash_table, input_data):
    data0 = int.from_bytes(input_data[:8], byteorder="little")
    data1 = int.from_bytes(input_data[8:], byteorder="little")
    for i in range(0x22):
        hash_val = int.from_bytes(hash_table[i * 8: (i + 1) * 8], byteorder="little")
        data1 = validate(hash_val ^ (data0 + ((data1 >> 8) | (data1 << 56))))
        data0 = validate(data1 ^ ((data0 >> 0x3D) | (data0 << 3)))
    output_data = bytearray(16)
    output_data[:8] = data0.to_bytes(8, byteorder="little")
    output_data[8:] = data1.to_bytes(8, byteorder="little")
    return bytes(output_data)

def encrypt_ladon(md5hex: bytes, data: bytes, size: int):
    hash_table = bytearray(272 + 16)
    hash_table[:32] = md5hex
    temp = [int.from_bytes(hash_table[i * 8: (i + 1) * 8], byteorder="little") for i in range(4)]
    buffer_b0, buffer_b8 = temp[0], temp[1]
    temp.pop(0)
    temp.pop(0)
    for i in range(0x22):
        x8 = validate(__ROR__(ctypes.c_ulonglong(buffer_b8), 8))
        x8 = validate(x8 + buffer_b0)
        x8 = validate(x8 ^ i)
        temp.append(x8)
        x8 = validate(x8 ^ __ROR__(ctypes.c_ulonglong(buffer_b0), 61))
        set_type_data(hash_table, i + 1, x8, "uint64_t")
        buffer_b0 = x8
        buffer_b8 = temp.pop(0)
    new_size = padding_size(size)
    input_bytes = bytearray(new_size)
    input_bytes[:size] = data
    pkcs7_padding_pad_buffer(input_bytes, size, new_size, 16)
    output = bytearray(new_size)
    for i in range(new_size // 16):
        output[i * 16: (i + 1) * 16] = encrypt_ladon_input(hash_table, input_bytes[i * 16: (i + 1) * 16])
    return output

def ladon_encrypt(khronos: int, lc_id: int = 1611921764, aid: int = 1233,
                  random_bytes: bytes = None) -> str:
    if random_bytes is None:
        random_bytes = os.urandom(4)
    data = f"{khronos}-{lc_id}-{aid}"
    keygen = random_bytes + str(aid).encode()
    md5hex = md5bytes(keygen)
    size = len(data)
    new_size = padding_size(size)
    output = bytearray(new_size + 4)
    output[:4] = random_bytes
    output[4:] = encrypt_ladon(md5hex.encode(), data.encode(), size)
    return base64.b64encode(bytes(output)).decode()

class Ladon:
    @staticmethod
    def encrypt(x_khronos: int, lc_id: int, aid: int) -> str:
        return ladon_encrypt(x_khronos, lc_id, aid)