import hashlib
import time
from .gorgon import Gorgon
from .ladon import Ladon
from .argus import Argus

def sign(params: str, payload: str = None, sec_device_id: str = '',
         cookie: str = None, aid: int = 1233, license_id: int = 1611921764,
         sdk_version_str: str = 'v05.00.06-ov-android', sdk_version: int = 167775296,
         platform: int = 0, unix: float = None):
    x_ss_stub = hashlib.md5(payload.encode('utf-8')).hexdigest() if payload is not None else None
    if not unix:
        unix = time.time()
    result = Gorgon(params, unix, payload, cookie).get_value()
    result.update({
        'content-length': str(len(payload)) if payload else '0',
        'x-ss-stub': x_ss_stub.upper() if x_ss_stub else '',
        'x-ladon': Ladon.encrypt(int(unix), license_id, aid),
        'x-argus': Argus.get_sign(params, x_ss_stub, int(unix), platform=platform,
                                  aid=aid, license_id=license_id, sec_device_id=sec_device_id,
                                  sdk_version=sdk_version_str, sdk_version_int=sdk_version)
    })
    return result