import hashlib
import json
import time

class Gorgon:
    def __init__(self, params: str, unix: int, data: str = None, cookies: str = None) -> None:
        self.unix = unix
        self.params = params
        self.data = data
        self.cookies = cookies

    def hash(self, data: str) -> str:
        return str(hashlib.md5(data.encode()).hexdigest())

    def get_base_string(self) -> str:
        base_str = self.hash(self.params)
        base_str += self.hash(self.data) if self.data else "0" * 32
        base_str += self.hash(self.cookies) if self.cookies else "0" * 32
        return base_str

    def get_value(self) -> dict:
        return self.encrypt(self.get_base_string())

    def encrypt(self, data: str) -> dict:
        len_val = 0x14
        key = [0xDF, 0x77, 0xB9, 0x40, 0xB9, 0x9B, 0x84, 0x83, 0xD1, 0xB9,
               0xCB, 0xD1, 0xF7, 0xC2, 0xB9, 0x85, 0xC3, 0xD0, 0xFB, 0xC3]
        param_list = []
        for i in range(0, 12, 4):
            temp = data[8 * i: 8 * (i + 1)]
            for j in range(4):
                param_list.append(int(temp[j * 2: (j + 1) * 2], 16))
        param_list.extend([0x0, 0x6, 0xB, 0x1C])
        H = int(hex(int(self.unix)), 16)
        param_list.append((H & 0xFF000000) >> 24)
        param_list.append((H & 0x00FF0000) >> 16)
        param_list.append((H & 0x0000FF00) >> 8)
        param_list.append((H & 0x000000FF) >> 0)
        eor_result_list = [A ^ B for A, B in zip(param_list, key)]
        for i in range(len_val):
            C = self.reverse(eor_result_list[i])
            D = eor_result_list[(i + 1) % len_val]
            E = C ^ D
            F = self.rbit_algorithm(E)
            H_val = ((F ^ 0xFFFFFFFF) ^ len_val) & 0xFF
            eor_result_list[i] = H_val
        result = "".join(self.hex_string(param) for param in eor_result_list)
        return {
            "x-ss-req-ticket": str(int(self.unix * 1000)),
            "x-khronos": str(int(self.unix)),
            "x-gorgon": f"0404b0d30000{result}"
        }

    def rbit_algorithm(self, num):
        tmp_string = bin(num)[2:].zfill(8)
        result = tmp_string[::-1]
        return int(result, 2)

    def hex_string(self, num):
        tmp_string = hex(num)[2:]
        if len(tmp_string) < 2:
            tmp_string = "0" + tmp_string
        return tmp_string

    def reverse(self, num):
        tmp_string = self.hex_string(num)
        return int(tmp_string[1:] + tmp_string[:1], 16)