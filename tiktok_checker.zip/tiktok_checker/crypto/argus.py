import time
import random
import base64
import hashlib
from struct import unpack
from urllib.parse import parse_qs
from Crypto.Cipher.AES import new, MODE_CBC, block_size
from Crypto.Util.Padding import pad
from .sm3 import SM3
from .simon import simon_enc
from .protobuf import ProtoBuf

class Argus:
    @staticmethod
    def encrypt_enc_pb(data, l):
        data = list(data)
        xor_array = data[:8]
        for i in range(8, l):
            data[i] ^= xor_array[i % 8]
        return bytes(data[::-1])

    @staticmethod
    def get_bodyhash(stub: str = None) -> bytes:
        if stub is None or len(stub) == 0:
            return SM3().sm3_hash(bytes(16))[0:6]
        return SM3().sm3_hash(bytes.fromhex(stub))[0:6]

    @staticmethod
    def get_queryhash(query: str) -> bytes:
        if query is None or len(query) == 0:
            return SM3().sm3_hash(bytes(16))[0:6]
        return SM3().sm3_hash(query.encode())[0:6]

    @staticmethod
    def encrypt(xargus_bean: dict):
        protobuf = pad(bytes.fromhex(ProtoBuf(xargus_bean).toBuf().hex()), block_size)
        new_len = len(protobuf)
        sign_key = b'\xac\x1a\xda\xae\x95\xa7\xaf\x94\xa5\x11J\xb3\xb3\xa9}\xd8\x00P\xaa\n91L@R\x8c\xae\xc9RV\xc2\x8c'
        sm3_output = b'\xfcx\xe0\xa9ez\x0ct\x8c\xe5\x15Y\x90<\xcf\x03Q\x0eQ\xd3\xcf\xf22\xd7\x13C\xe8\x8a2\x1cS\x04'
        key = sm3_output[:32]
        key_list = []
        for _ in range(2):
            key_list += list(unpack("<QQ", key[_ * 16: _ * 16 + 16]))
        enc_pb = bytearray(new_len)
        for _ in range(new_len // 16):
            pt = list(unpack("<QQ", protobuf[_ * 16: _ * 16 + 16]))
            ct = simon_enc(pt, key_list)
            enc_pb[_ * 16: _ * 16 + 8] = ct[0].to_bytes(8, byteorder="little")
            enc_pb[_ * 16 + 8: _ * 16 + 16] = ct[1].to_bytes(8, byteorder="little")
        b_buffer = Argus.encrypt_enc_pb((b"\xf2\xf7\xfc\xff\xf2\xf7\xfc\xff" + enc_pb), new_len + 8)
        b_buffer = b'\xa6n\xad\x9fw\x01\xd0\x0c\x18' + b_buffer + b'ao'
        cipher = new(hashlib.md5(sign_key[:16]).digest(), MODE_CBC, hashlib.md5(sign_key[16:]).digest())
        return base64.b64encode(b"\xf2\x81" + cipher.encrypt(pad(b_buffer, block_size))).decode()

    @staticmethod
    def get_sign(queryhash: str = None, data: str = None, timestamp: int = None,
                 aid: int = 1233, license_id: int = 1611921764, platform: int = 0,
                 sec_device_id: str = "", sdk_version: str = "v04.04.05-ov-android",
                 sdk_version_int: int = 134744640) -> str:
        if timestamp is None:
            timestamp = int(time.time())
        params_dict = parse_qs(queryhash)
        try:
            vn = params_dict['version_name'][0]
        except KeyError:
            vn = params_dict['app_version'][0]
        return Argus.encrypt({
            1: 0x20200929 << 1,
            2: 2,
            3: random.randint(0, 0x7FFFFFFF),
            4: str(aid),
            5: params_dict['device_id'][0],
            6: str(license_id),
            7: vn,
            8: sdk_version,
            9: sdk_version_int,
            10: bytes(8),
            12: (timestamp << 1),
            13: Argus.get_bodyhash(data),
            14: Argus.get_queryhash(queryhash),
            16: sec_device_id,
            20: "none",
            21: 738,
            25: 2
        })