from core.checker import TikTokChecker

if __name__ == "__main__":
    checker = TikTokChecker(max_workers=100, max_retries=1)
    checker.run()