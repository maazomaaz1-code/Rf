import random
import string
import uuid
import re

def generate_random_hex(length=16):
    chars = '0123456789abcdef'
    return ''.join(random.choice(chars) for _ in range(length))

def generate_samsung_device():
    samsung_models = ["SM-G975F", "SM-G998B", "SM-A525F", "SM-T870", "SM-J600G",
                      "SM-G780F", "SM-A127F", "SM-T220", "SM-G991B", "SM-A037G",
                      "SM-J250F", "SM-T735C", "SM-G610F", "SM-A205GN", "SM-J730GM",
                      "SM-T395C", "SM-G532G", "SM-A105M", "SM-J260GU", "SM-T295",
                      "SM-G960F", "SM-J710F", "SM-A315G", "SM-T500"]
    return random.choice(samsung_models)

def generate_random_device():
    iid = str(random.randint(7400000000000000000, 7499999999999999999))
    did = str(random.randint(7400000000000000000, 7499999999999999999))
    device_type = generate_samsung_device()
    device_brand = "samsung"
    openudid = generate_random_hex(16)
    cdid = str(uuid.uuid4())
    return f"{iid}:{did}:{device_type}:{device_brand}:{openudid}:{cdid}"

def generate_verifyFp():
    prefix = "verify_"
    part1 = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    part2 = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    part3 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    part4 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    part5 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    part6 = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    return f"{prefix}{part1}_{part2}_{part3}_{part4}_{part5}_{part6}"

def xor_value(value: str) -> str:
    return "".join(hex(ord(_) ^ 5)[2:] for _ in value)

def contains_arabic(text):
    return bool(re.search(r'[\u0600-\u06FF]', text))