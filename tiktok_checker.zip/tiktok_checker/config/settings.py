import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, 'data')

proxies_list = []

def load_proxies():
    global proxies_list
    try:
        with open(os.path.join(DATA_DIR, "proxies.txt"), "r") as f:
            proxy_lines = [line.strip() for line in f if ":" in line]
            if not proxy_lines:
                raise ValueError("Proxy list is empty or invalid.")
            for proxy in proxy_lines:
                if proxy.count(":") == 3:
                    host, port, user, pwd = proxy.split(":")
                    proxies_list.append(f"{user}:{pwd}@{host}:{port}")
                else:
                    proxies_list.append(proxy)
    except FileNotFoundError:
        pass

def load_telegram_settings():
    try:
        with open(os.path.join(DATA_DIR, "setings.json"), 'r', encoding='utf-8') as h:
            data_settings = json.load(h)
            return data_settings.get('admin_id', ''), data_settings.get('admin_token', '')
    except FileNotFoundError:
        return '', ''

load_proxies()
ADMIN_ID, ADMIN_TOKEN = load_telegram_settings()